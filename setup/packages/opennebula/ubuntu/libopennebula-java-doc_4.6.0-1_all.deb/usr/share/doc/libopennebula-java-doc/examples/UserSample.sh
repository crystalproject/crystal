#!/bin/bash

java -cp ../../lib/*:../../jar/*:. UserSample
